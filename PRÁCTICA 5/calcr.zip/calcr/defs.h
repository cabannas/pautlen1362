#ifndef DEFS_H
#define DEFS_H


#define MAX_VARS 52
#define NUMERO 0
#define VARIABLE 1


#endif  /* DEFS_H */
